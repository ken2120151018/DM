package dataHandler;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;

public class DataConversion {

	public static void main(String[] args) throws Exception{
		// TODO �Զ����ɵķ������ 

		String path = "D:/Data Mining/train.csv";
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(path), "UTF-8"));

		String savePath = "D:/Data Mining/train_processed.csv";
		FileWriter fileWritter = new FileWriter(savePath);
		BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
		reader.readLine();
		//��Ҫ��һ��
		
		String msg = null;
		int i = 1;
		while ( (msg = reader.readLine()) != null ){
			System.out.println((i++) +"   "+ msg);
			String [] info = msg.split(",");
			if(Conversation(info)){
			bufferWritter.write(info[0] + ","+info[1] + ","+info[2] + ","+info[3] + ","+info[4] + ","+info[5] + "\n");
			System.out.print(info[0] + ","+info[1] + ","+info[2] + ","+info[3] + ","+info[4] + ","+info[5] + "\n");
			}
		}
		reader.close();
		bufferWritter.close();
	}

	private static boolean Conversation(String[] info) {
		// TODO �Զ����ɵķ������
		
		for ( int i = 0 ; i < 5 ; i++  )
			if ( info[i].equals("") )
				return false;
		if ( info[0].equals("1") )
			info[0] = "Survived";
		else if ( info[0].equals("0") )
			info[0] = "notSurvived";
		if ( Double.valueOf(info[3]) > 0 && Double.valueOf(info[3]) <= 10  )
			info[3] = "kid";
		else if ( Double.valueOf(info[3]) > 10 && Double.valueOf(info[3]) <= 20  )
			info[3] = "teenager";
		else if ( Double.valueOf(info[3]) > 20 && Double.valueOf(info[3]) <= 40  )
			info[3] = "young";
		else if ( Double.valueOf(info[3]) > 40 && Double.valueOf(info[3]) <= 60  )
			info[3] = "midage";
		else if ( Double.valueOf(info[3]) > 60   )
			info[3] = "elder";
		if ( Double.valueOf(info[4]) > 0 )
			info[4] = "offspring";
		else 
			info[4] = "Nooffspring";
		if (  Double.valueOf(info[5]) < 20  )
			info[5] = "poor";
		else if (  Double.valueOf(info[5]) < 50  )
			info[5] = "midclass";
		else if (  Double.valueOf(info[5]) < 100  )
			info[5] = "rich";
		else
			info[5] = "superrich";
		return true;
	}

}
